Icons 128x128 dedicated for Mobydock's set of weather conditions.

Copyright 2005 by Wojciech Grzanka. All rights reserved.

Contact: wojciech@iconbest.com, iconbest.com

------------------------------------
NOT FOR COMMERCIAL USE !!!
------------------------------------

All non-personal use is prohibited unless permission is given by author.

---
See also: "Grzanka's Icons"
